This directory contains images that are used in CUDA-Q Academic notebooks either published or under development.
