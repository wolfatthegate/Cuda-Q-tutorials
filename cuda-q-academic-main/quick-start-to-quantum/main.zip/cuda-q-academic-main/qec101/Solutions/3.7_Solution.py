"""
Using an off-resonance frequency means there is not hte same energy transfer and the peak only goes up to around 0.8, even without decoherence.  Changing the time range means that the pulse no longer stops at its peak and has started to slightly decay. 
"""